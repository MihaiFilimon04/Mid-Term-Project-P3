public interface Storable {
    void saveData();
    void loadData();
}
